var locale=navigator.language||window.navigator.language||"en-US";const _get=(n,t,e)=>{let i=new XMLHttpRequest;i.open("GET",n,!0),i.responseType="json",i.setRequestHeader("Content-Type","application/json; charset=UTF-8"),i.onreadystatechange=e,i.send(JSON.stringify(t))},_post=(n,t,e)=>{let i=new XMLHttpRequest;i.open("POST",n,!0),i.setRequestHeader("Content-Type","application/json; charset=UTF-8"),i.onreadystatechange=e,i.send(JSON.stringify(t))};function _delete(n,t,e){let i=new XMLHttpRequest;i.open("DELETE",n,!0),i.setRequestHeader("Content-Type","application/json; charset=UTF-8"),i.onreadystatechange=e,i.send(JSON.stringify(t))}const MAXFILESOPEN=2,base=window.location.href.split("/view")[0],title=document.title.split("/"),namespace=title[0],repoName=title[1];class BuildCard{_card;ID;Branch;_files;_commit;_commitLink;_buildPrefix;_date;get commit(){return this._commit}set commit(t){this._commit=t,this._commitLink.textContent=t.substring(0,7),this._buildPrefix=`${base}/repo/${repo.Namespace}/${repo.Name}/build/${t}`}get Link(){return this._commitLink.href}set Link(t){this._commitLink.href=t}get Name(){return this._card.querySelector(".build-name").textContent}set Name(t){this._card.querySelector(".build-name").textContent=t}get Date(){return this._date}set Date(t){this._date=t;const e=this._card.querySelector(".build-date");e.textContent=`${t.toLocaleDateString(locale)} @ ${t.toLocaleTimeString(locale)}`}get Files(){return this._files}set Files(t){const e=this._card.querySelector("input.build-dropdown"),i=this._card.querySelector(".accordion"),s=this._card.querySelector(".build-files"),a=this._card.querySelector(".build-nofiles");if(t&&t.length!=0){this._files=t;let l="";for(let r of t)l+=`
                <li class="menu-item">
                    <a href="${this._buildPrefix}/${r.Name}">${r.Name} <i class="menu-badge text-gray">${r.Size}</i></a>
                </li>
                `;e.checked=t.length<=MAXFILESOPEN,s.innerHTML=l,i.style.display="",a.style.display="none"}else i.style.display="none",a.style.display=""}constructor(t,e){this._card=document.createElement("div"),this._card.innerHTML=`
        <div class="card minicard">
            <div class="columns col-gapless">
                <div class="column">
                    <div class="card-header">
                        <a class="card-title h5 text-monospace build-commit"></a>
                        <div class="card-subtitle text-gray text-monospace build-name"></div>
                        <div class="card-subtitle text-gray build-date"></div>
                    </div>
                </div>
                <div class="divider-vert"></div>
                <div class="column">
                    <div class="card-body">
                        <div class="accordion">
                            <input type="checkbox" id="dropdown_${e}" name="dropdown_${e}" class="build-dropdown" hidden>
                            <label class="accordion-header" for="dropdown_${e}">
                                <i class="icon icon-arrow-right mr-1"></i>
                                <a>Files</a>
                            </label>
                            <div class="accordion-body">
                                <ul class="menu menu-nav accordionList build-files"></ul>
                            </div>
                        </div>
                        <p class="text-gray build-nofiles">No files published for this commit.</p>
                    </div>
                <div>
            </div>
        </div>
        `,this._commitLink=this._card.querySelector(".build-commit"),this.commit=e,this.ID=t.ID,this.Name=t.Name,this.Date=t.Date,this.Files=t.Files,this.Link=t.Link,this.Branch=t.Branch}asElement=()=>this._card}const branchArea=document.getElementById("branch-area"),contentBox=document.getElementById("content");class BranchTabs{_current="";tabs;constructor(){this.tabs=[]}tabEl=t=>{for(let e of this.tabs)if(e.Branch==t)return e.tabEl};addTab=t=>{let e={};e.Branch=t,e.tabEl=document.createElement("div"),e.tabEl.style.display="none",contentBox.appendChild(e.tabEl),e.buttonEl=document.createElement("a"),e.buttonEl.classList.add("text-gray","mr-1"),e.buttonEl.textContent=t+" ",e.buttonEl.onclick=()=>{this.switch(t)},branchArea.appendChild(e.buttonEl),this.tabs.push(e)};get current(){return this._current}set current(t){this.switch(t)}switch=t=>{this._current=t;for(let e of this.tabs)e.Branch==t?(e.tabEl.style.display="",e.buttonEl.classList.remove("text-gray")):(e.tabEl.style.display="none",e.buttonEl.classList.add("text-gray"))}}var repo,buildOrder=[],currentPage=1;_get(`${base}/repo/${namespace}/${repoName}`,null,function(){if(this.readyState==4&&this.status==200){repo=this.response,repo.Builds={};for(let n of repo.Branches)(n=="main"||n=="master")&&branchTabs.addTab(n);for(let n of repo.Branches)n=="main"||n=="master"||branchTabs.addTab(n);repo.BuildPageCount!=0&&getPage(1)}});var currentBranch="",branchTabs=new BranchTabs;const getPage=n=>_get(`${base}/repo/${namespace}/${repoName}/builds/${n}`,null,function(){if(this.readyState==4){const t=document.getElementById("loadMore");if(this.status==200){currentPage=n,t.remove();const e=this.response;for(const i of e.Order){const s=e.Builds[i];(s.Branch=="main"||s.Branch=="master")&&currentBranch==""&&(currentBranch=s.Branch,branchTabs.current=s.Branch);let a=branchTabs.tabEl(s.Branch);s.Date=new Date(s.Date),buildOrder.push(i),repo.Builds[i]=new BuildCard(s,i),a.appendChild(repo.Builds[i].asElement())}currentBranch==""&&(currentBranch=repo.Branches[0],branchTabs.current=repo.Branches[0])}t.onclick=()=>getPage(currentPage+1),currentPage+1<=repo.BuildPageCount&&contentBox.appendChild(t)}});
