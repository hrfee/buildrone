function toClipboard(e){const n=document.createElement("textarea");n.value=e,n.readOnly=!0,n.style.position="absolute",n.style.left="-9999px",document.body.appendChild(n);const s=document.getSelection().rangeCount>0?document.getSelection().getRangeAt(0):!1;n.select(),document.execCommand("copy"),document.body.removeChild(n),s&&(document.getSelection().removeAllRanges(),document.getSelection().addRange(s))}const _get=(e,n,s)=>{let t=new XMLHttpRequest;t.open("GET",e,!0),t.responseType="json",t.setRequestHeader("Authorization","Bearer "+btoa(window.token)),t.setRequestHeader("Content-Type","application/json"),t.onreadystatechange=s,t.send(JSON.stringify(n))},_post=(e,n,s)=>{let t=new XMLHttpRequest;t.open("POST",e,!0),t.responseType="json",t.setRequestHeader("Authorization","Bearer "+btoa(window.token)),t.setRequestHeader("Content-Type","application/json; charset=UTF-8"),t.onreadystatechange=s,t.send(JSON.stringify(n))};function _delete(e,n,s){let t=new XMLHttpRequest;t.open("DELETE",e,!0),t.setRequestHeader("Authorization","Bearer "+btoa(window.token)),t.setRequestHeader("Content-Type","application/json; charset=UTF-8"),t.onreadystatechange=s,t.send(JSON.stringify(n))}const rmAttr=(e,n)=>{e.classList.contains(n)&&e.classList.remove(n)},addAttr=(e,n)=>e.classList.add(n),Focus=e=>rmAttr(e,"unfocused"),Unfocus=e=>addAttr(e,"unfocused"),genCard=e=>{const n=e.LatestCommit!="";let s="";e.Secret&&n&&e.LatestCommit.length>=7&&(s=e.LatestCommit.substring(0,7));let t=`${base}/view/${e.Namespace}/${e.Name}`,i="";e.Secret?(i=`
        <a href="${t}" class="card-title h5">${e.Namespace}/${e.Name}</a>
        `,n?i+=`<a href="${e.LatestPush.Link}" class="card-title h5 text-monospace text-gray">${s}</a>
            <div class="card-subtitle text-gray">Last commit: ${e.LatestPush.Date.toLocaleDateString("en-US")} @ ${e.LatestPush.Date.toLocaleTimeString("en-US")}</div>
            `:i+='<div class="card-subtitle text-gray">No commits yet.</div>',i+=`
        `):i=`
        <a class="card-title h5 text-gray">${e.Namespace}/${e.Name}</a>
        <div class="card-subtitle text-gray">Not configured.</div>
        `;let o="";e.Secret&&(o=`
        <button class="btn btn-lg btn-error" onclick="newSecretWarning('${e.Namespace}', '${e.Name}', this)" style="margin: 0.5rem;">New Secret</button>
        `);let a=`
    <div class="card minicard">
        <div class="columns col-gapless">
            <div class="column">
                <div class="card-header">
                    ${i}
                </div>
            </div>
            <div class="divider-vert"></div>
            <div class="column">
                <div class="card-body" style="padding-bottom: 0.8rem;">
                    <button class="btn btn-lg ${e.Secret?"btn-primary":""}" onclick="newKey('${e.Namespace}', '${e.Name}', false, this)" style="margin: 0.5rem;">${e.Secret?"New Key":"Setup"}</button>
                    ${o}
                    <div class="textArea"></div>
                </div>
            <div>
        </div>
    </div>
    `;const d=document.createElement("div");return d.innerHTML=a,d.firstElementChild},emptyCard=()=>{const e=document.createElement("div");return e.innerHTML=`
    <div class="card empty">
        <div class="empty-subtitle">
            Setup repositories in Drone to see them here.
        </div>
    </div>
    `,e.firstElementChild};var newSecretButtonEl;function newSecretWarning(e,n,s){newSecretButtonEl=s,document.getElementById("newSecretSubmit").setAttribute("onclick",`newKey('${e}', '${n}', true, newSecretButtonEl)`),addAttr(document.getElementById("secretWarningModal"),"active")}function newKey(e,n,s,t){const i=t.parentElement.getElementsByClassName("textArea")[0];i.textContent="";const o=!t.classList.contains("btn-error");addAttr(t,"loading");const a=t.textContent;let d={NewSecret:s};_post(`/repo/${e}/${n}/key`,d,function(){if(this.readyState==4)if(rmAttr(document.getElementById("secretWarningModal"),"active"),rmAttr(t,"loading"),this.status!=200)addAttr(t,"btn-error"),rmAttr(t,"btn-primary"),t.textContent="Failed",setTimeout(()=>{addAttr(t,"btn-primary"),o&&rmAttr(t,"btn-error"),t.textContent=a},3e3);else{addAttr(t,"btn-success"),rmAttr(t,"btn-primary");const u=this.response.Key;t.textContent="Success";const r=document.createElement("button");r.classList.add("btn","text-monospace"),r.setAttribute("style","width: 6rem; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; margin: 0.5rem;");const c=document.createElement("p");addAttr(c,"text-gray"),s&&(c.textContent+=`
                    A new secret has been generated. All previous build keys are now invalid.
                    `),c.textContent+=`

                Click the above build key to copy it, and store it as the 'BUILDRONE_KEY' environment variable in Drone for the upload script to use.`,r.innerHTML=`
                <i class="icon icon-copy"></i> ${u}
                `,r.onclick=()=>{toClipboard(u);const l=document.createElement("div");addAttr(l,"toast");const m=document.createElement("button");m.classList.add("btn","btn-clear","float-right"),m.onclick=()=>l.remove(),l.appendChild(m),l.appendChild(document.createTextNode("Copied to clipboard.")),c.appendChild(l),setTimeout(()=>l.remove(),5e3)},i.appendChild(r),i.appendChild(c),setTimeout(()=>{r.remove(),c.remove(),rmAttr(t,"btn-primary"),rmAttr(t,"btn-success"),t.textContent=a},6e4)}})}const base=window.location.origin;let repoList={};var repoOrder=[];const loginModal=document.getElementById("loginModal");function login(e,n,s,t){const i=new XMLHttpRequest;i.responseType="json",i.open("GET","/token",!0),i.setRequestHeader("Authorization","Basic "+btoa(e+":"+n)),i.onreadystatechange=function(){if(this.readyState==4){const o=document.getElementById("loginButton");if(rmAttr(o,"loading"),this.status!=200){let a=this.response.error;a||(a="Unknown error"),s?(o.disabled=!1,o.textContent=a,addAttr(o,"btn-error"),rmAttr(o,"btn-primary"),setTimeout(()=>{addAttr(o,"btn-primary"),rmAttr(o,"btn-error"),o.textContent="Login"},4e3)):addAttr(loginModal,"active")}else{const a=this.response;window.token=a.token,loadRepos(),rmAttr(loginModal,"active")}t&&t(+this.status)}},i.send()}document.getElementById("loginForm").onsubmit=function(){const e=document.getElementById("loginButton");addAttr(e,"loading");const n=document.getElementById("username").value,s=document.getElementById("password").value;return login(n,s,!0,null),!1},login("","",!1,e=>{e==200||e==204||addAttr(loginModal,"active")});const loadRepos=()=>_get("/repos",null,function(){if(this.readyState==4&&this.status==200){repoList=this.response;for(const n of Object.keys(repoList))repoList[n].LatestPush.Date=new Date(repoList[n].LatestPush.Date),repoOrder.push(n);repoOrder=repoOrder.sort((n,s)=>repoList[s].Secret==repoList[n].Secret?repoList[s].Secret&&repoList[s].LatestCommit!=""&&repoList[n].LatestCommit!=""?repoList[s].LatestPush.Date.getTime()-repoList[n].LatestPush.Date.getTime():0:repoList[s].Secret?1:-1);const e=document.getElementById("content");for(let n=0;n<repoOrder.length;n++)e.appendChild(genCard(repoList[repoOrder[n]]));repoOrder.length<2&&e.appendChild(emptyCard())}});
